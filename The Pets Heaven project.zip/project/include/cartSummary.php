<!--Danah Alharbi-->
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="CSS/header%20and%20menu%20bar.css">
    </head>
    
    <body>
        <?php //this function will go through 2D array $_SESSION['cart']['pid'] to display cart summary
            
            $total_price=0.0;
            $total_products=0.0;
        
            if(isset($_SESSION['cart']) && isset($_SESSION['connection'])){
                
                foreach($_SESSION['cart'] as $pid => $quantity){
                    
                    $query="SELECT Price FROM Product WHERE ProductID='$pid'";
                    
                     $result = mysqli_query($_SESSION["connection"], $query);
                    
                    if (mysqli_num_rows($result) > 0){
                        $row=mysqli_fetch_row($result);
                        $total_products+=$quantity;
                        $total=$quantity*$row[0];
                        $total_price+=$total;
                    }

                }
            }
            
                    echo '<span id="cart-info"> '. $total_products . ' items - SAR '. $total_price . '</span>';
                
        ?>
    </body></html>
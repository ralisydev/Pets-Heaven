<!--Shahad Almalki-->
<?php 
session_start();
require("../include/connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
     <meta name="description" content="Contact Pets Heaven store in Riyadh, Saudi Arabia. Get in touch with us for pet products, inquiries, and support.">
    <meta name="keywords" content="pet store, pet products, Riyadh pet shop, pets toys, pets food, contact Pets Heaven, contact us">
    <title>Contact Us - Pets Heaven</title>
    <link rel="stylesheet" type="text/css" href="../CSS/header%20and%20menu%20bar.css">
    <link rel="stylesheet" type="text/css" href="../CSS/contact%20us.css">
</head>
<body>
    <div class="header">Pets Heaven</div> <!--Shop's name-->
    <!--start menu bar-->
    <div class="navbar">
        <!--start drop-down menus-->
        <ul class="nav-links"> 
            <li><a href="../index.php">Home</a></li>
            <li><a href="admin%20authentication%20page.php">Admin</a></li>
        </ul>
        <!-- Display total number of items and price in cart -->
        <?php echo "<div class='cart'> ";
                    echo '<a href="cart page.php" class="cart-icon">🛒</a>'; 
         include("../include/cartSummary.php"); 
        echo "</div>";?> 
        </div>
        <!--end menu bar-->
    
    <div class="container-wrapper">
        <!--store infomation-->
        <div class="container">
            <h2>Contact Us</h2>
            <p>📞 Phone: 0138888888</p>
            <p>📧 Email: <a class="address" href=mailto:info@petsheaven.com> info@petsheaven.com</a></p>
            <p>📍 Location: Pets Heaven Store, Riyadh, Saudi Arabia</p>
            
                    <!-- Embed live map -->

             <iframe 
          src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d57230.80239870895!2d50.1365979!3d26.2965264!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e49e9eca725c0ed%3A0x1f630d6fb3bc82da!2z2KjZitiqINio2KfYsdmDINin2YTYrtio2LEgUGV0UGFyaw!5e0!3m2!1sen!2ssa!4v1746122204436!5m2!1sen!2ssa" 
          width="100%" 
          height="300" 
          style="border:0; border-radius: 5px;" 
          allowfullscreen 
          loading="lazy" 
          referrerpolicy="no-referrer-when-downgrade">
        </iframe> <!--including google maps service (store's location)-->
            <button onclick="window.open('https://maps.app.goo.gl/fsXGZUvC99b4mayVA')">
            Open in Google Maps
        </button> <!--using javascript to open google maps-->

            
        
            
        </div>
        <!--end of store infomation-->
        
    </div>
    
                
</body>
</html>
 <?php require("include/close connection.php");?>
<!--Darah-->
<?php
session_start();
include("../include/connection.php");

// Fetch products from database
$products = [];
$result = mysqli_query($_SESSION["connection"], "SELECT * FROM Product");
while ($row = mysqli_fetch_assoc($result)) {
    $products[$row['ProductID']] = [
        'name' => $row['Name'],
        'price' => $row['Price'],
        'stock' => $row['Stock'],
        'animal' => $row['AnimalType'],
        'image' => $row['Image'],
        'type' => $row['ProductType']
    ];
}

if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_cart']) && !empty($_SESSION['cart'])) {
        if (isset($_POST['quantities']) && is_array($_POST['quantities'])) {
            foreach ($_POST['quantities'] as $pid => $qty) {
                $qty = intval($qty);
                if ($qty > 0 && isset($products[$pid]) && $qty <= $products[$pid]['stock']) {
                    $_SESSION['cart'][$pid] = $qty;
                }
            }
        }
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    if (isset($_POST['remove_item'])) {
        $pid = $_POST['remove_item'];
        if (isset($_SESSION['cart'][$pid])) {
            unset($_SESSION['cart'][$pid]);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Invalid product ID']);
        }
        exit;
    }

    if (isset($_POST['buy'])) {
        if (empty($_SESSION['cart'])) {
            echo "<script>alert('Your cart is empty.'); window.location.href = window.location.href;</script>";
            exit;
        }
        foreach ($_SESSION['cart'] as $pid => $qty) {
            if (isset($products[$pid])) {
                $currentStock = $products[$pid]['stock'];
                $newStock = max(0, $currentStock - $qty);
                $updateQuery = "UPDATE Product SET Stock = $newStock WHERE ProductID = $pid";
                mysqli_query($_SESSION['connection'], $updateQuery);
                setcookie("cart[$pid]", $qty, time() + 86400 * 7, "/");
            }
        }
        $_SESSION['cart'] = [];
        header("Location: Thank you page.html");
        exit;
    }

    if (isset($_POST['delete_all']) && !empty($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
        echo "<script>window.location.href = window.location.href;</script>";
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Pets Heaven</title>
  <link rel="stylesheet" href="../css/cart.css"/>
  
</head>
<body>
  <div class="header">Pets Heaven</div>
  <div class="cart-container">
    <a href="../index.php"><button class="leave-cart">Leave Cart</button></a>

    <form method="post" id="cart-form">
      <div class="all-items">
        <?php
        if (empty($_SESSION['cart'])) {
            echo "<p style='font-size: 18px; margin: 20px;'>Your cart is empty.</p>";
        } else {
          $total = 0;
          foreach ($_SESSION['cart'] as $pid => $qty):
              if (!isset($products[$pid])) continue;
              $product = $products[$pid];
              $name = $product['name'];
              $price = $product['price'];
              $stock = $product['stock'];
              $animal = $product['animal'];
              $image = $product['image'];
              $type = $product['type'];
              $subtotal = $price * $qty;
              $total += $subtotal;
        ?>
        <div class="cart-item" data-id="<?= htmlspecialchars($pid) ?>" data-price="<?= $price ?>" data-stock="<?= $stock ?>" data-qty="<?= $qty ?>">
          <div class="item-details">
            <img src="../Images/<?= htmlspecialchars($image) ?>" alt="<?= htmlspecialchars($animal . ' - ' . $type) ?>" />
            <span><?= htmlspecialchars($name) ?></span>
          </div>
          <div class="price-section">
            <span>SAR <?= number_format($price, 2) ?></span>
            <div class="quantity-container">
              <input type="number" name="quantities[<?= $pid ?>]" class="quantity-input" value="<?= $qty ?>" min="1" max="<?= $stock ?>" />
            </div>
            <div class="item-total">Total: SAR <?= number_format($subtotal, 2) ?></div>
            <span class="remove-item" style="cursor:pointer;">&times;</span>
          </div>
        </div>
        <?php endforeach; } ?>
      </div>

      <div class="total-container">
        <div class="total">Total: SAR <?= isset($total) ? number_format($total, 2) : '0.00' ?></div>
        <div class="buttons">
          <button type="submit" name="update_cart" class="update-btn">Update Cart</button>
          <button type="submit" name="buy" class="buy-btn">Buy</button>
          <button type="button" id="delete-all-btn" class="delete-btn">Delete All Items</button>
        </div>
      </div>
    </form>
  </div>

  <script>
    const quantityInputs = document.querySelectorAll('.quantity-input');
    const totalDisplay = document.querySelector('.total');

    function updateTotals(allowInvalid = false) {
      let total = 0;
      let valid = true;
      document.querySelectorAll('.cart-item').forEach(item => {
        const price = parseFloat(item.dataset.price);
        const qtyInput = item.querySelector('.quantity-input');
        const originalQty = parseInt(item.dataset.qty);
        const qty = parseInt(qtyInput.value);
        const stock = parseInt(item.dataset.stock);

        let error = '';
        if (!qty || qty <= 0) error = "Quantity must be at least 1";
        else if (qty > stock) error = "Quantity exceeds stock";

        if (error) {
          alert(error);
          qtyInput.value = originalQty;
          qtyInput.focus();
          valid = false;
        } else {
          const subtotal = price * qty;
          item.querySelector('.item-total').textContent = `Total: SAR ${subtotal.toFixed(2)}`;
          total += subtotal;
        }
      });
      totalDisplay.textContent = `Total: SAR ${total.toFixed(2)}`;
      return allowInvalid || valid;
    }

    quantityInputs.forEach(input => {
      input.addEventListener('input', () => updateTotals(true));
    });

    document.getElementById('cart-form').addEventListener('submit', function(e) {
      if (!updateTotals(false)) {
        e.preventDefault();
      }
    });

    document.querySelectorAll('.remove-item').forEach(btn => {
      btn.addEventListener('click', () => {
        const itemDiv = btn.closest('.cart-item');
        const pid = itemDiv.dataset.id;

        if (confirm("Are you sure you want to remove this product?")) {
          itemDiv.remove();
          updateTotals();
          if (document.querySelectorAll('.cart-item').length === 0) {
            document.querySelector('.all-items').innerHTML = '<p style="font-size: 18px;">Your cart is now empty.</p>';
            totalDisplay.textContent = 'Total: SAR 0.00';
          }

          fetch(window.location.href, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: new URLSearchParams({ remove_item: pid })
          })
          .then(res => res.json())
          .then(data => {
            if (!data.success) {
              alert("Failed to remove item from the session cart.");
            }
          });
        }
      });
    });

    document.querySelector('.delete-btn').addEventListener('click', (e) => {
      e.preventDefault();
      if (document.querySelectorAll('.cart-item').length === 0) {
        alert("Your cart is already empty.");
        return;
      }
      if (confirm("Are you sure you want to delete all items from the cart?")) {
        fetch(window.location.href, {
          method: 'POST',
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          body: new URLSearchParams({ delete_all: true })
        })
        .then(() => {
          document.querySelector('.all-items').innerHTML = '<p style="font-size: 18px;">Your cart is now empty.</p>';
          totalDisplay.textContent = 'Total: SAR 0.00';
        });
      }
    });

    updateTotals(true);
  </script>
</body>
</html>

<!--RAGHAD LISLOUM -->

<?php
session_start();
include '../include/connection.php';

if (!isset($_SESSION['is_manager'])) {
    header("Location: admin authentication page.php");
    exit();
}


$name = $animalType = $productType = $price = $stock = $description = $image = "";
$message = "";
$errors = [];

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $search_name = mysqli_real_escape_string($db_link, $_POST['search_name'] ?? '');

  if (!empty($search_name)) {
    $query = "SELECT * FROM product WHERE Name = '$search_name'";
    $result = mysqli_query($db_link, $query);

    if (mysqli_num_rows($result) > 0) {
      $row = mysqli_fetch_assoc($result);
      $name = $row['Name'];
      $animalType = $row['AnimalType'];
      $productType = $row['ProductType'];
      $price = $row['Price'];
      $stock = $row['Stock'];
      $description = $row['Description'];
      $image = $row['Image'];
      $message = ""; // Clear any previous error message
    } else {
      $message = "Product not found.";
      // Clear form fields to ensure no stale data is displayed
      $name = $animalType = $productType = $price = $stock = $description = $image = "";
    }
  }

  if (isset($_POST['modify'])) {
    $name = mysqli_real_escape_string($db_link, $_POST['name'] ?? '');
    $animalType = mysqli_real_escape_string($db_link, $_POST['animalType'] ?? '');
    $productType = mysqli_real_escape_string($db_link, $_POST['category'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $stock = intval($_POST['stock'] ?? 0);
    $description = mysqli_real_escape_string($db_link, $_POST['description'] ?? '');

    // Validate required fields
    if (empty($name)) {
      $errors['name'] = "This field is required.";
    }
    if (empty($animalType)) {
      $errors['animalType'] = "This field is required.";
    }
    if (empty($productType)) {
      $errors['productType'] = "This field is required.";
    }
    if (!isset($_POST['price']) || $_POST['price'] === '') {
      $errors['price'] = "This field is required.";
    }
    if (!isset($_POST['stock']) || $_POST['stock'] === '') {
      $errors['stock'] = "This field is required.";
    }
    if (empty($description)) {
      $errors['description'] = "This field is required.";
    }

    if (empty($errors)) {
      // Check for duplicate name (excluding the current product)
      $check_query = "SELECT COUNT(*) FROM product WHERE Name = ? AND Name != ?";
      $stmt = mysqli_prepare($db_link, $check_query);
      mysqli_stmt_bind_param($stmt, "ss", $name, $search_name);
      mysqli_stmt_execute($stmt);
      mysqli_stmt_bind_result($stmt, $count);
      mysqli_stmt_fetch($stmt);
      mysqli_stmt_close($stmt);

      if ($count > 0) {
        $message = "This product name already exists.";
      } else {
        if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
          $image_tmp = $_FILES['image']['tmp_name'];
          $image_name = basename($_FILES['image']['name']);
          $upload_dir = '../Images/';
          $target_file = $upload_dir . $image_name;

          if (move_uploaded_file($image_tmp, $target_file)) {
            $image = $image_name;
          } else {
            $message = "Failed to upload image.";
          }
        }

        if (empty($message)) {
          $update_query = "UPDATE product SET 
                                  Name = '$name',
                                  AnimalType = '$animalType',
                                  ProductType = '$productType',
                                  Price = $price,
                                  Stock = $stock,
                                  Description = '$description',
                                  Image = '$image'
                               WHERE Name = '$search_name'";

          if (mysqli_query($db_link, $update_query)) {
            $_SESSION['message'] = "Product updated successfully.";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
          } else {
            $message = "Error updating product: " . mysqli_error($db_link);
          }
        }
      }
    }
  }

  if (isset($_POST['delete'])) {
    $name = mysqli_real_escape_string($db_link, $_POST['name']);

    // Check if the product exists
    $check_query = "SELECT * FROM product WHERE Name = '$name'";
    $check_result = mysqli_query($db_link, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
      $delete_query = "DELETE FROM product WHERE Name = '$name'";
      if (mysqli_query($db_link, $delete_query) && mysqli_affected_rows($db_link) > 0) {
        $_SESSION['message'] = "Product deleted successfully.";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
      } else {
        $message = "Error deleting product: " . mysqli_error($db_link);
      }
    } else {
      $message = "Product not found.";
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Modify and Delete Product - Pets Heaven</title>
  <link rel="stylesheet" href="../css/add%20and%20modify%20page.css">
            <style>
    .delete-button {
        width: 170px; 
        background-color: #f44336; 
        color: white; 
        border: none; 
        padding:  12px 20px; 
        border-radius: 6px; 
        font-size: 16px;
        cursor: pointer; 
        font-weight: bold; /* Optional */
    }

    .delete-button:hover {
        background-color: #c62828; /* Darker red on hover */
    }
    .clear-button {
        width: 100px; 
        background-color: #d87c37; 
        color: white; 
        border: none; 
        padding:  12px 20px; 
        border-radius: 6px;
        font-size: 16px; 
        cursor: pointer; 
        font-weight: bold; /* Optional */
    }

    .clear-button:hover {
        background-color: #b9652e;
    }
</style>
</head>

<body>
  <div class="header">Pets Heaven</div>
  <div class="container">
    <div class="form-container">
      <form id="productForm" name="productForm" method="POST" enctype="multipart/form-data" autocomplete="on">
        <div class="back-button-container">
          <a href="Admin%20dashboard.php" class="back-to-home-button">Back to Home Page</a>
          <input type="search" class="search-bar" name="search_name" placeholder="Search products..." value="<?php echo htmlspecialchars($search_name ?? ''); ?>" required>
          <input type="submit" name="search" value="Search" style="width: 100px; background-color: #d87c37; color: white; border: none; padding: 12px 20px; border-radius: 5px; cursor: pointer; font-size: 16px; font-weight:Bold ">
        </div>

        <div class="page-title">Modify or Delete Product</div>

        <p><label>Name:</label></p>
        <p><input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>" placeholder="Enter product name"></p>
        <p><span class="error" style="color: red; font-size: 0.8em;"><?php echo isset($errors['name']) ? htmlspecialchars($errors['name']) : ''; ?></span></p>

        <p><label>Animal Type:</label></p>
        <p>
          <select name="animalType">
            <option value="" disabled <?php echo empty($animalType) ? 'selected' : ''; ?>>Select Animal Type</option>
            <option value="dog" <?php echo $animalType == 'dog' ? 'selected' : ''; ?>>Dog</option>
            <option value="cat" <?php echo $animalType == 'cat' ? 'selected' : ''; ?>>Cat</option>
            <option value="bird" <?php echo $animalType == 'bird' ? 'selected' : ''; ?>>Bird</option>
          </select>
        </p>
        <p><span class="error" style="color: red; font-size: 0.8em;"><?php echo isset($errors['animalType']) ? htmlspecialchars($errors['animalType']) : ''; ?></span></p>

        <p><label>Product Type:</label></p>
        <p>
          <select name="category">
            <option value="" disabled <?php echo empty($productType) ? 'selected' : ''; ?>>Select Product Type</option>
            <option value="Food" <?php echo $productType == 'Food' ? 'selected' : ''; ?>>Food</option>
            <option value="Toy" <?php echo $productType == 'Toy' ? 'selected' : ''; ?>>Toy</option>
          </select>
        </p>
        <p><span class="error" style="color: red; font-size: 0.8em;"><?php echo isset($errors['productType']) ? htmlspecialchars($errors['productType']) : ''; ?></span></p>

        <p><label>Price:</label></p>
        <p><input type="number" name="price" value="<?php echo htmlspecialchars($price); ?>" placeholder="Enter price" step="0.01"></p>
        <p><span class="error" style="color: red; font-size: 0.8em;"><?php echo isset($errors['price']) ? htmlspecialchars($errors['price']) : ''; ?></span></p>

        <p><label>Stock Available:</label></p>
        <p><input type="number" name="stock" value="<?php echo htmlspecialchars($stock); ?>" placeholder="Enter stock quantity" min="0"></p>
        <p><span class="error" style="color: red; font-size: 0.8em;"><?php echo isset($errors['stock']) ? htmlspecialchars($errors['stock']) : ''; ?></span></p>

        <p><label>Description:</label></p>
        <p><textarea name="description" placeholder="Enter product description"><?php echo htmlspecialchars($description); ?></textarea></p>
        <p><span class="error" style="color: red; font-size: 0.8em;"><?php echo isset($errors['description']) ? htmlspecialchars($errors['description']) : ''; ?></span></p>

        <p><label>Image:</label></p>
        <p><input type="file" name="image" accept="image/*"></p>
        <?php if (!empty($image)): ?>
          <p><img src="../Images/<?php echo htmlspecialchars($image); ?>" alt="Product Image" style="max-width: 200px; height: auto; border-radius: 5px;"></p>
        <?php endif; ?>

        <?php
        if (isset($_SESSION['message'])) {
          echo '<p style="color: green; font-weight: bold;">' . htmlspecialchars($_SESSION['message']) . '</p>';
          unset($_SESSION['message']);
        } elseif (!empty($message)) {
          echo '<p style="color: red; font-weight: bold;">' . htmlspecialchars($message) . '</p>';
        }
        ?>

        <div class="button-container clearfix">
          <input type="submit" name="modify" value="Modify">

        </div>


<input type="button" class="clear-button" value="Clear" onclick="window.location.href = window.location.href;">
<input type="submit" name="delete" value="Delete Product" class="delete-button">

        
      </form>
    </div>
  </div>
</body>

</html>
<?php
mysqli_close($db_link);
?>

<script>

  function validateFields() {
    const form = document.getElementById("productForm");
    const requiredFields = ["name", "animalType", "category", "price", "stock", "description"];
    
    for (let field of requiredFields) {
      const input = form[field];
      if (!input || input.value.trim() === "") {
        alert("Please fill in all fields.");
        return false;
      }
    }
    return true;
  }

  // Attach event listeners to the Modify and Delete buttons
  window.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("productForm");
    const modifyBtn = form.querySelector('input[name="modify"]');
    const deleteBtn = form.querySelector('input[name="delete"]');

    if (modifyBtn) {
      modifyBtn.addEventListener("click", function (e) {
        if (!validateFields()) e.preventDefault();
      });
    }

    if (deleteBtn) {
      deleteBtn.addEventListener("click", function (e) {
        if (!validateFields()) e.preventDefault();
      });
    }
  });


    //this function can also be used to clear the form but it won't remove the error messages from php

  function clearForm() {
    const form = document.getElementById('productForm');
    form.reset(); // Resets form fields to their default values

    // Additionally, clear any fields that are pre-populated with PHP variables
    form.querySelectorAll('input[type="text"], input[type="number"], textarea').forEach(field => {
      field.value = '';
    });

    form.querySelectorAll('select').forEach(select => {
      select.selectedIndex = 0;
    });

    // Clear file input
    const fileInput = form.querySelector('input[type="file"]');
    if (fileInput) {
      fileInput.value = '';
    }
  }
</script>
<!--Reef-->
<?php
session_start();
include("../include/connection.php");

$error_message = "";

// Handle login POST request
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (isset($_SESSION["connection"])) {
        $query = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
        $result = mysqli_query($_SESSION["connection"], $query);

        if (mysqli_num_rows($result) == 1) {
            $_SESSION['is_manager'] = true;
            header("Location: Admin dashboard.php");
            exit();
        } else {
            $error_message = "Invalid login.";
        }
    } else {
        $error_message = "Database connection failed.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Admin login page for Pets Heaven - Add, edit, or remove pet product listings. Secure access for administrators.">
    <meta name="keywords" content="Pets Heaven, Pet Shop, Admin Login, Pet Products, Online Pet Store, Pet Supplies">
    <title>Admin Authentication - Pets Heaven</title>
    <link rel="stylesheet" href="../CSS/admin_authentication_css.css">

</head>
<body>
    <!-- Header -->
    <div class="header">Pets Heaven</div>

    <!-- Authentication Container -->
    <div class="auth-container">
        <h2>Welcome to Pets Heaven</h2>
        <h3>Log In</h3>


        <!-- Login Form -->
        <form id="loginForm" action="#" method="post">
            <input type="text" placeholder="Username" name="username" id="username">
            <input type="password" placeholder="Password" name="password" id="password">
            <!--error message if the user entered invalid credintials-->
            <?php if ($error_message != "") { ?>
            <div style="color:red; font-weight:bold; margin:5px;"> <?php echo $error_message; ?> Please try again.</div>
        <?php } ?>
            
            <div class="button-container">
                <input type="reset" value="Clear">
                <input type="submit" value="Log In">
            </div>

            <div class="button-container">
                <a href="../index.php" class="homepage-button">Go to Home Page</a>
            </div>
            
        </form>
        
    </div>

    <!-- JavaScript Validation -->
    <script>
        document.getElementById("loginForm").addEventListener("submit", function(e) {
            const username = document.getElementById("username").value.trim();
            const password = document.getElementById("password").value.trim();

            if (username === "" || password === "") {
                alert("Please fill in both username and password fields.");
                e.preventDefault();
            }
        });
    </script>
</body>
    <?php  require("include/close connection.php");?>
</html>

<!-- Albandari Aldossari -->
<?php
session_start(); // Start the session to access session variables
require("../include/connection.php"); // Include the database connection

$error_message = ""; // Variable to hold error messages
$product = null; // Variable to hold product data

// Function to fetch product from the database based on product ID
function fetchProduct($pid) {
    $conn = $_SESSION["connection"]; // Get the database connection from session
    $pid = mysqli_real_escape_string($conn, $pid); // Escape the product ID to prevent SQL injection
    $query = "SELECT * FROM Product WHERE ProductID = '$pid'"; // SQL query to fetch product
    $result = mysqli_query($conn, $query); // Execute the query
    return mysqli_fetch_assoc($result); // Return the product as an associative array
}

// Check if a product ID is provided in the URL
if (isset($_GET['pid'])) {
    $pid = $_GET['pid']; // Get the product ID from the URL
    $product = fetchProduct($pid); // Fetch the product data

    // Check if the product exists
    if ($product) {
        // Check if the form has been submitted
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $qty = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1; // Get the quantity from the form
            $action = $_POST["action"] ?? "add"; // Determine the action (add to cart or checkout)

            if ($qty > 0) { // Check if the quantity is valid
                if ($qty <= $product['Stock']) { // Check if the requested quantity is available
                    $_SESSION['cart'][$pid] = ($_SESSION['cart'][$pid] ?? 0) + $qty; // Add quantity to cart
                    $error_message = "Added to cart!"; // Success message

                    // Redirect to cart page if action is checkout
                    if ($action === "checkout") {
                        header("Location: cart%20page.php");
                        exit; // Stop script execution
                    }
                } else {
                    $error_message = "Sorry, only {$product['Stock']} items available."; // Error for insufficient stock
                }
            } else {
                $error_message = "Invalid quantity."; // Error for invalid quantity
            }
        }
    } else {
        $error_message = "Product not found."; // Error if product does not exist
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Product Details - Pets Heaven</title>
    <link rel="stylesheet" href="../CSS/Product%20Details.css" /> <!-- Link to product details CSS -->
    <link rel="stylesheet" href="../CSS/header%20and%20menu%20bar.css" /> <!-- Link to header and menu CSS -->
    <style>.error-message { color: red;
        font-weight: bold;}</style> <!-- Style for error messages -->
</head>
<body>
    <div class="header">Pets Heaven</div> <!-- Header of the page -->

    <nav class="navbar">
        <ul class="nav-links">
            <li><a href="../index.php">Home</a></li> 
            <li><a href="contact%20us%20page.php">Contact Us</a></li> 
            <li><a href="admin%20authentication%20page.php">Admin</a></li> 
        </ul>
        <!-- Display total number of items and price in cart -->
        <?php echo "<div class='cart'> ";
                    echo '<a href="cart page.php" class="cart-icon">🛒</a>'; 
         include("../include/cartSummary.php"); 
        echo "</div>";?> 
    </nav>

    <section class="product-detail-container">
        <?php if (!isset($_GET['pid'])) { ?>
            <p class="error-message">A product hasn't been selected. <a href="../index.php">Go to Home Page</a></p>
        <?php } elseif ($product) { ?>
            <div class="image-container">
                <img src="../Images/<?php echo $product['Image']; ?>"
                     alt="<?php echo $product['AnimalType'] . ' - ' . $product['ProductType']; ?>"> 
            </div>
            <div class="product-info">
                <h2><?php echo $product['Name']; ?></h2> 
                <p><?php echo $product['AnimalType'] . ' - ' . $product['ProductType']; ?></p> 
                <p><strong>SAR <?php echo $product['Price']; ?></strong></p> 

                <form method="post"> <!-- Form for adding product to cart -->
                    <input type="hidden" name="action" id="form-action" value=""> <!-- Hidden input for action -->
                    <div class="quantity-container">
                        <label for="quantity">Quantity:</label>
                        <input type="number" id="quantity" name="quantity" value="1" min="1" max="30"
                               oninput="validateQuantity(this)" onblur="checkEmpty(this)"> <!-- Quantity input -->
                    </div>
                    <div class="description">
                        <h3>Product Description:</h3>
                        <div class="button-group">
                            <button type="button" class="btn details-btn"
                                    onclick="showAlert('<?php echo $product['Description']; ?>')">
                                For more details click here
                            </button> <!-- Button to show product description -->
                            <button type="submit" class="btn addcart-btn" onclick="setAction('add')">Add to Cart</button> <!-- Button to add to cart -->
                            <button type="submit" class="btn chk-btn" onclick="setAction('checkout')">Checkout</button> <!-- Button to checkout -->
                        </div>
                    </div>
                </form>
                <?php if ($error_message) {
                    echo "<p class='error-message'>$error_message</p>"; // Display error message if exists
                } ?>
            </div>
        <?php } else { ?>
            <p class="error-message"><?php echo $error_message; ?></p> <!-- Display product not found error -->
        <?php } ?>
    </section>

    <script>
        // Function to show an alert with the product description
        function showAlert(description) {
            alert(description);
        }

        // Validate quantity input
        function validateQuantity(input) {
            let value = input.value.replace(/[^0-9]/g, ''); // Remove non-numeric characters
            input.value = value;

            let num = parseInt(value);
            if (num < 1 && value !== "") {
                alert("Quantity must be at least 1."); // Alert for invalid quantity
                input.value = 1;
            } else if (num > 30) {
                alert("Maximum quantity is 30."); // Alert for exceeding max quantity
                input.value = 30;
            }
        }

        // Check if quantity input is empty
        function checkEmpty(input) {
            if (input.value.trim() === "") {
                alert("Quantity must be at least 1."); // Alert if empty
                input.value = 1;
            }
        }

        // Set the action based on button clicked
        function setAction(type) {
            document.getElementById("form-action").value = type; // Set hidden input value
        }
    </script>
    <?php  require("include/close connection.php");?>
</body>
</html>